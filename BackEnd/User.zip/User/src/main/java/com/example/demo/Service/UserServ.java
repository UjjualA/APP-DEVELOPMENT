package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.UserEntity;
import com.example.demo.Repository.UserRepos;

@Service
public class UserServ {
	@Autowired
	private UserRepos use;
	
	public UserEntity saveDetails(UserEntity s)
	{
		return use.save(s);
	}
	public List<UserEntity> getAllDetails(){
		List<UserEntity>arr=new ArrayList<>();
		arr=(List<UserEntity>)use.findAll();
		return arr;
	}
	public void deleteById(int Id) {
		use.deleteById(Id);
	}
	public UserEntity update(Long Id,UserEntity s) {
		return use.saveAndFlush(s);
	}
	public Optional<UserEntity>findById(int Id)
	{
		Optional<UserEntity>user=use.findById(Id);
		return user;
	}
}
