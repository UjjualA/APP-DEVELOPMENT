package com.example.demo.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Model.ReservationEntity;
import com.example.demo.Service.ReservationServ;

@RestController
@CrossOrigin("*")
@RequestMapping("/rrr")
public class ReservationControl {
	@Autowired
	private ReservationServ serv;
	
	@GetMapping("/getres")
	public List<ReservationEntity> showUsers(){	
		return serv.getAllDetails();
	}
	@PostMapping("/addres")
	public ReservationEntity addUser(@RequestBody ReservationEntity obj) {
		return serv.saveDetails(obj);
	}
	@DeleteMapping("/deleteres/{id}")
	public String delUser(@PathVariable int Id) {
		serv.deleteById(Id);
		return "Deleted Successfully";
	}
	@GetMapping("/getres/{id}")
	public Optional<ReservationEntity>findById(@PathVariable int Id){
		return serv.findById(Id);
	}
	@PutMapping("/updateres/{id}")
	public ReservationEntity update(@PathVariable Long Id,@RequestBody ReservationEntity s)
	{
		return serv.update(Id,s);
	}
}
