package com.example.demo.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Model.ReservationEntity;
import com.example.demo.Repository.ReservationRepos;



@Service
public class ReservationServ {
	@Autowired
	private ReservationRepos use;
	
	public ReservationEntity saveDetails(ReservationEntity s)
	{
		return use.save(s);
	}
	public List<ReservationEntity> getAllDetails(){
		List<ReservationEntity>arr=new ArrayList<>();
		arr=(List<ReservationEntity>)use.findAll();
		return arr;
	}
	public void deleteById(int Id) {
		use.deleteById(Id);
	}
	public ReservationEntity update(Long Id,ReservationEntity s) {
		return use.saveAndFlush(s);
	}
	public Optional<ReservationEntity>findById(int Id)
	{
		Optional<ReservationEntity>user=use.findById(Id);
		return user;
	}
}
