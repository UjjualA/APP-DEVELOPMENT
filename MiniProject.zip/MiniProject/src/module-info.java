/**
 * 
 */
/**
 * @author ujjual
 *
 */
module MiniProject {
	requires java.sql;
}