package com.example.demo.Files;

public interface Printable {
	void print();
}
