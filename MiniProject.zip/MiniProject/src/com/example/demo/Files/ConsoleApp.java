package com.example.demo.Files;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ConsoleApp {
    public static void main(String[] args) throws SQLException {
        DatabaseManager.getConnection();

        boolean running = true;
        while (running) {
            System.out.println("===== Social Networking Application =====");
            System.out.println("1. Create Profile");
            System.out.println("2. Add Friend");
            System.out.println("3. Post Message");
            System.out.println("4. View Posts");
            System.out.println("5. View Friends List");
            System.out.println("6. View User List");
            System.out.println("7. Print");
            System.out.println("8. Exit");
            System.out.println("===========================================");

            int choice = Inputhelper.getIntInput("Enter your choice:");

            switch (choice) {
                case 1:
                    createUserProfile();
                    break;
                case 2:
                    addFriend();
                    break;
                case 3:
                    postMessage();
                    break;
                case 4:
                    viewPosts();
                    break;
                case 5:
                    displayFriendsList();
                    break;
                case 6:
                	viewUserList();
                	break;
                case 7:
                    printUserDetails();
                    break;
                case 8:
                	running = false;
                	break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        DatabaseManager.close();
        System.out.println("Bye.....");
    }
    private static void createUserProfile() {
        int id = Inputhelper.getIntInput("Enter ID:");
        String username = Inputhelper.getInput("Enter username:");
        String email = Inputhelper.getInput("Enter email:");
        int age = Inputhelper.getIntInput("Enter Age:");
        boolean isPremium = Inputhelper.getBoolInput("Is the user a premium member? (true/false):");

        if (isPremium) {
            String subscriptionType = Inputhelper.getInput("Enter subscription type:");
            String expiryDateStr = Inputhelper.getInput("Enter subscription expiry date (YYYY-MM-DD):");
            LocalDate expiryDate = LocalDate.parse(expiryDateStr);

            premiumUser newPremiumUser = new premiumUser(id, id, username, email, age, subscriptionType, expiryDate);
            newPremiumUser.setPremium(true);
            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement premiumUserStatement = connection.prepareStatement(
                         "INSERT INTO premium_user (premium_id, user_id, subscription_type, subscription_expiry) VALUES (?, ?, ?, ?)");
                 PreparedStatement userStatement = connection.prepareStatement(
                         "INSERT INTO mini (id, username, email, age) VALUES (?, ?, ?, ?)")) {

                userStatement.setInt(1, newPremiumUser.getId());
                userStatement.setString(2, newPremiumUser.getUsername());
                userStatement.setString(3, newPremiumUser.getEmail());
                userStatement.setInt(4, newPremiumUser.getAge());
                userStatement.executeUpdate();

                premiumUserStatement.setInt(1, newPremiumUser.getPremiumId());
                premiumUserStatement.setInt(2, newPremiumUser.getId());
                premiumUserStatement.setString(3, newPremiumUser.getSubscriptionType());
                premiumUserStatement.setDate(4, Date.valueOf(newPremiumUser.getSubscriptionExpiry()));
                premiumUserStatement.executeUpdate();

                System.out.println("Premium user profile created successfully!");

            } catch (SQLException e) {
                System.err.println("Error creating premium user profile: " + e.getMessage());
            }
        } else {
            User newUser = new User(id, username, email, age) {
                @Override
                public void printUserProfile() {
                    System.out.println("User Profile:");
                    System.out.println("ID: " + getId());
                    System.out.println("Username: " + getUsername());
                    System.out.println("Email: " + getEmail());
                    System.out.println("Age: " + getAge());
                    System.out.println();
                }
            };

            try (Connection connection = DatabaseManager.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "INSERT INTO mini (id, username, email, age) VALUES (?, ?, ?, ?)")) {

                preparedStatement.setInt(1, newUser.getId());
                preparedStatement.setString(2, newUser.getUsername());
                preparedStatement.setString(3, newUser.getEmail());
                preparedStatement.setInt(4, newUser.getAge());

                preparedStatement.executeUpdate();
                System.out.println("Regular user profile created successfully!");

            } catch (SQLException e) {
                System.err.println("Error creating regular user profile: " + e.getMessage());
            }
        }
    }
    
    private static void printUserDetails() {
        int userId = Inputhelper.getIntInput("Enter user ID:");
        User user = fetchUserById(userId);
        if (user == null) {
            System.out.println("User not found!");
        } else {
            int printChoice = Inputhelper.getIntInput("Choose print option:\n1. Using printUserProfile()\n2. Using print()\nEnter choice:");
            switch (printChoice) {
                case 1:
                    user.printUserProfile();
                    break;
                case 2:
                    if (user instanceof Printable) {
                        Printable printableUser = (Printable) user;
                        printableUser.print();
                    } else {
                        System.out.println("User does not support Printable interface.");
                    }
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static User fetchUserById(int userId) {
        try (Connection connection = DatabaseManager.getConnection()) {
            List<Printable> users = fetchDataByUserId(connection, userId,
                    "SELECT id, username, email, age, is_premium, subscription_type, subscription_expiry FROM mini " +
                    "LEFT JOIN premium_user ON user.id = premium_user.user_id " +
                    "WHERE user.id = ?");
            if (!users.isEmpty()) {
                Printable user = users.get(0);
                if (user instanceof User) {
                    return (User) user;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching user from the database: " + e.getMessage());
        }
        return null;
    }
    
    private static List<Printable> fetchDataByUserId(Connection connection, int userId, String query) {
        List<Printable> data = new ArrayList<>();

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");
                int age = resultSet.getInt("age");

                boolean isPremium = resultSet.getBoolean("is_premium");
                if (isPremium) {
                    String subscriptionType = resultSet.getString("subscription_type");
                    LocalDate subscriptionExpiry = resultSet.getDate("subscription_expiry").toLocalDate();
                    premiumUser user = new premiumUser(id, id, username, email, age, subscriptionType, subscriptionExpiry);
                    user.setPremium(true);
                    data.add(user);
                } else {
                    User user = new User(id, username, email, age) {
                        @Override
                        public void printUserProfile() {
                            System.out.println("User Profile:");
                            System.out.println("ID: " + getId());
                            System.out.println("Username: " + getUsername());
                            System.out.println("Email: " + getEmail());
                            System.out.println("Age: " + getAge());
                            System.out.println("Premium: " + isPremium());
                            System.out.println();
                        }
                    };
                    data.add(user);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching data from the database: " + e.getMessage());
        }

        return data;
    }

    private static void addFriend() {
        int userId = Inputhelper.getIntInput("Enter your user ID:");
        int friendId = Inputhelper.getIntInput("Enter your friend's user ID:");

        try (Connection connection = DatabaseManager.getConnection()) {
            if (!userExists(connection, userId) || !userExists(connection, friendId)) {
                System.out.println("One or both users do not exist. Please enter valid user IDs.");
                return;
            }

            if (areAlreadyFriends(connection, userId, friendId)) {
                System.out.println("You are already friends!");
                return;
            }

            try (PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO friends (user_id, friend_id) VALUES (?, ?)")) {
                preparedStatement.setInt(1, userId);
                preparedStatement.setInt(2, friendId);
                preparedStatement.executeUpdate();
                System.out.println("Friend added successfully!");
            } catch (SQLException e) {
                System.out.println("Error adding friend: " + e.getMessage());
            }

        } catch (SQLException e) {
            System.out.println("Error connecting to the database: " + e.getMessage());
        }
    }

    private static boolean userExists(Connection connection, int userId) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement("SELECT COUNT(*) AS count FROM mini WHERE id = ?")) {
            preparedStatement.setInt(1, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt("count") > 0;
            }
        }
    }

    private static boolean areAlreadyFriends(Connection connection, int userId, int friendId) throws SQLException {
        try (PreparedStatement preparedStatement = connection.prepareStatement(
                "SELECT COUNT(*) AS count FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)")) {
            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, friendId);
            preparedStatement.setInt(3, friendId);
            preparedStatement.setInt(4, userId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next() && resultSet.getInt("count") > 0;
            }
        }
    }

    private static void postMessage() {
        int userId = Inputhelper.getIntInput("Enter your user ID:");
        String content = Inputhelper.getInput("Enter your message:");

        Posts newPost = new Posts();
        newPost.setUserId(userId);
        newPost.setContent(content);

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO posts (user_id, content) VALUES (?, ?)")) {

            preparedStatement.setInt(1, newPost.getUserId());
            preparedStatement.setString(2, newPost.getContent());

            preparedStatement.executeUpdate();
            System.out.println("Message posted successfully!");

        } catch (SQLException e) {
            System.err.println("Error posting message: " + e.getMessage());
        }
    }

    private static void viewPosts() {
        int userId = Inputhelper.getIntInput("Enter user ID:");

        try (Connection connection = DatabaseManager.getConnection()) {
            List<Posts> posts = getPostsByUserId(connection, userId);

            for (Posts post : posts) {
                System.out.println("Post ID: " + post.getId());
                System.out.println("User ID: " + post.getUserId());
                System.out.println("Content: " + post.getContent());
                System.out.println("Created At: " + post.getCreatedAt());
                System.out.println();
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }

    private static void displayFriendsList() {
        int userId = Inputhelper.getIntInput("Enter user ID:");

        try (Connection connection = DatabaseManager.getConnection()) {
            List<Friend> friends = getFriendsList(connection, userId);

            if (friends.isEmpty()) {
                System.out.println("No friends found for the user with ID " + userId);
            } else {
                System.out.println("Friends List for User ID " + userId + ":");
                for (Friend friend : friends) {
                    friend.printUserProfile();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }

    private static List<Posts> getPostsByUserId(Connection connection, int userId) {
        List<Posts> posts = new ArrayList<>();

        String query = "SELECT id, user_id, content, created_at FROM posts WHERE user_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int postId = resultSet.getInt("id");
                int postUserId = resultSet.getInt("user_id");
                String content = resultSet.getString("content");
                Timestamp createdAt = resultSet.getTimestamp("created_at");

                Posts post = new Posts();
                post.setId(postId);
                post.setUserId(postUserId);
                post.setContent(content);
                post.setCreatedAt(createdAt);

                posts.add(post);
            }

        } catch (SQLException e) {
            System.err.println("Error fetching posts from the database: " + e.getMessage());
        }

        return posts;
    }

    private static List<Friend> getFriendsList(Connection connection, int userId) {
        List<Friend> friends = new ArrayList<>();

        String query = "SELECT u.id, u.username, u.email, u.age FROM user u " +
                "JOIN friends f ON u.id = f.friend_id WHERE f.user_id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, userId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int friendId = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");
                int age = resultSet.getInt("age");

                Friend friend = new Friend(friendId, username, email, age);
                friends.add(friend);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching friends list from the database: " + e.getMessage());
        }

        return friends;
    }

    private static void viewUserList() {
        try (Connection connection = DatabaseManager.getConnection()) {
            List<User> users = fetchAllUsers(connection);

            if (users.isEmpty()) {
                System.out.println("No users found.");
            } else {
                System.out.println("User List:");
                for (User user : users) {
                    user.printUserProfile();
                }
            }
        } catch (SQLException e) {
            System.err.println("Error connecting to the database: " + e.getMessage());
        }
    }

    private static List<User> fetchAllUsers(Connection connection) {
        List<User> users = new ArrayList<>();

        String query = "SELECT id, username, email, age FROM user";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String username = resultSet.getString("username");
                String email = resultSet.getString("email");
                int age = resultSet.getInt("age");

                User user = new User(id, username, email, age) {
                    @Override
                    public void printUserProfile() {
                        System.out.println("User Profile:");
                        System.out.println("ID: " + getId());
                        System.out.println("Username: " + getUsername());
                        System.out.println("Email: " + getEmail());
                        System.out.println("Age: " + getAge());
                        System.out.println();
                    }
                };
                users.add(user);
            }

        } catch (SQLException e) {
            System.err.println("Error fetching users from the database: " + e.getMessage());
        }

        return users;
    }
}